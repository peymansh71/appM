import React from "react";

export default function DispatchScreen() {
  return <div>this tab shows DispatchScreen</div>;
}
