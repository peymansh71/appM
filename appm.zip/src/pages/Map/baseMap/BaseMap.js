import React from "react";

export default function BaseMap() {
  return <div>this tab shows map</div>;
}
