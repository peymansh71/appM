import {createContext} from 'react';
const context = createContext('map');;
export default context;
